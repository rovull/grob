<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/announcement' => [[['_route' => 'announcement', '_controller' => 'App\\Controller\\AnnouncementController::index'], null, null, null, false, false, null]],
        '/edit_announcement' => [[['_route' => 'edit_announcement', '_controller' => 'App\\Controller\\AnnouncementController::updateAnnouncement'], null, ['POST' => 0], null, false, false, null]],
        '/publish_announcement' => [[['_route' => 'publish_announcement', '_controller' => 'App\\Controller\\AnnouncementController::addAnnouncement'], null, ['POST' => 0], null, false, false, null]],
        '/all_announcement' => [[['_route' => 'all_announcement', '_controller' => 'App\\Controller\\AnnouncementController::allAnnouncement'], null, ['GET' => 0], null, false, false, null]],
        '/get-announcement' => [[['_route' => 'get-announcement', '_controller' => 'App\\Controller\\AnnouncementController::allAnnouncementById'], null, ['GET' => 0], null, false, false, null]],
        '/get-bill-announcement-by-user' => [[['_route' => 'get-bill-announcement-by-user', '_controller' => 'App\\Controller\\AnnouncementController::allAnnouncementBillByUser'], null, ['GET' => 0], null, false, false, null]],
        '/get-future-announcement' => [[['_route' => 'get-future-announcement', '_controller' => 'App\\Controller\\AnnouncementController::allFutureAnnouncementById'], null, ['GET' => 0], null, false, false, null]],
        '/get-years-obituaries' => [[['_route' => 'get-years-obituaries', '_controller' => 'App\\Controller\\AnnouncementController::allPublichAnnouncementById'], null, ['GET' => 0], null, false, false, null]],
        '/get-all-announcement-admin' => [[['_route' => '/get-all-announcement-admin', '_controller' => 'App\\Controller\\AnnouncementController::getAllAnnouncementAdmin'], null, ['GET' => 0], null, false, false, null]],
        '/deactivate-announcement-admin' => [[['_route' => 'deactivate-announcement-admin', '_controller' => 'App\\Controller\\AnnouncementController::deactivateAnnouncement'], null, ['GET' => 0], null, false, false, null]],
        '/deactivate-announcement' => [[['_route' => 'deactivate-announcement', '_controller' => 'App\\Controller\\AnnouncementController::deactivateUserAnnouncement'], null, ['GET' => 0], null, false, false, null]],
        '/reactivate-announcement-admin' => [[['_route' => 'reactivate-announcement-admin', '_controller' => 'App\\Controller\\AnnouncementController::activateAnnouncement'], null, ['GET' => 0], null, false, false, null]],
        '/get-obituaries' => [[['_route' => 'get-obituaries', '_controller' => 'App\\Controller\\AnnouncementController::allYearPublichAnnouncementById'], null, ['GET' => 0], null, false, false, null]],
        '/delete-all-announcement-user' => [[['_route' => 'delete-all-announcement-user', '_controller' => 'App\\Controller\\AnnouncementController::deleteAllAnnouncementUser'], null, ['GET' => 0], null, false, false, null]],
        '/get-city' => [[['_route' => 'get-city', '_controller' => 'App\\Controller\\AnnouncementController::allCity'], null, ['GET' => 0], null, false, false, null]],
        '/get-all-years-announcement-admin' => [[['_route' => 'get-all-years-announcement-admin', '_controller' => 'App\\Controller\\AnnouncementController::allYears'], null, ['GET' => 0], null, false, false, null]],
        '/get-years-announcement' => [[['_route' => 'get-years-announcement', '_controller' => 'App\\Controller\\AnnouncementController::allYearsById'], null, ['GET' => 0], null, false, false, null]],
        '/get-filter' => [[['_route' => 'get-filter', '_controller' => 'App\\Controller\\AnnouncementController::allFilter'], null, ['GET' => 0], null, false, false, null]],
        '/uploadPDF' => [[['_route' => '/uploadPDF', '_controller' => 'App\\Controller\\AnnouncementController::uploadPDF'], null, ['POST' => 0], null, false, false, null]],
        '/makeFromPdfTextToSpeech' => [[['_route' => '/makeFromPdfTextToSpeech', '_controller' => 'App\\Controller\\AnnouncementController::uploadPDFText'], null, ['POST' => 0], null, false, false, null]],
        '/add_device' => [[['_route' => 'add_device', '_controller' => 'App\\Controller\\DevicesController::addDevice'], null, ['GET' => 0], null, false, false, null]],
        '/get_setting' => [[['_route' => '/get_setting', '_controller' => 'App\\Controller\\DevicesController::getSetting'], null, ['GET' => 0], null, false, false, null]],
        '/send_aplle' => [[['_route' => '/send_aplle', '_controller' => 'App\\Controller\\DevicesController::sendAndroid'], null, ['GET' => 0], null, false, false, null]],
        '/get-all-bills' => [[['_route' => 'get-all-bills', '_controller' => 'App\\Controller\\InvoicesController::allInvoices'], null, ['GET' => 0], null, false, false, null]],
        '/get-all-invoices' => [[['_route' => 'get-all-invoices', '_controller' => 'App\\Controller\\InvoicesController::allInvoicesByUser'], null, ['GET' => 0], null, false, false, null]],
        '/edit-bill-payment' => [[['_route' => 'edit-bill-paymen', '_controller' => 'App\\Controller\\InvoicesController::updateBill'], null, ['GET' => 0], null, false, false, null]],
        '/edit-bill-sum' => [[['_route' => 'edit-bill-sum', '_controller' => 'App\\Controller\\InvoicesController::updatePrice'], null, ['GET' => 0], null, false, false, null]],
        '/user' => [[['_route' => 'user', '_controller' => 'App\\Controller\\UserController::index'], null, null, null, false, false, null]],
        '/sendEmail' => [[['_route' => '/sendEmail', '_controller' => 'App\\Controller\\UserController::sendEmail'], null, ['POST' => 0], null, false, false, null]],
        '/write-to-support' => [[['_route' => 'write-to-support', '_controller' => 'App\\Controller\\UserController::sendEmailSup'], null, ['POST' => 0], null, false, false, null]],
        '/login' => [[['_route' => 'api_login', '_controller' => 'App\\Controller\\UserController::login'], null, ['POST' => 0], null, false, false, null]],
        '/change-user-password' => [[['_route' => '/change-user-password', '_controller' => 'App\\Controller\\UserController::updateUserPass'], null, ['POST' => 0], null, false, false, null]],
        '/change-user-email' => [[['_route' => 'change-user-email', '_controller' => 'App\\Controller\\UserController::updateUserEmail'], null, ['POST' => 0], null, false, false, null]],
        '/edit-user' => [[['_route' => 'edit-user', '_controller' => 'App\\Controller\\UserController::updateUser'], null, ['POST' => 0], null, false, false, null]],
        '/get-candidates' => [[['_route' => 'get-candidates', '_controller' => 'App\\Controller\\UserController::getCandidates'], null, ['GET' => 0], null, false, false, null]],
        '/unlock-candidate' => [[['_route' => 'unlock-candidate', '_controller' => 'App\\Controller\\UserController::unlockCandidate'], null, ['GET' => 0], null, false, false, null]],
        '/deny-candidate' => [[['_route' => 'deny-candidate', '_controller' => 'App\\Controller\\UserController::denyCandidate'], null, ['POST' => 0], null, false, false, null]],
        '/registration' => [[['_route' => 'api_registration', '_controller' => 'App\\Controller\\UserController::register'], null, ['POST' => 0], null, false, false, null]],
        '/profile' => [[['_route' => 'api_profile', '_controller' => 'App\\Controller\\UserController::profile'], null, null, null, false, false, null]],
        '/userForPhone' => [[['_route' => 'usertForPhone', '_controller' => 'App\\Controller\\UserController::profileForPhone'], null, null, null, false, false, null]],
        '/get-users' => [[['_route' => 'get-users', '_controller' => 'App\\Controller\\UserController::getUsers'], null, ['GET' => 0], null, false, false, null]],
        '/check-is-admin' => [[['_route' => 'check-is-admin', '_controller' => 'App\\Controller\\UserController::checkIsAdmin'], null, null, null, false, false, null]],
        '/deactivate-user' => [[['_route' => 'deactivate-user', '_controller' => 'App\\Controller\\UserController::deactivateUser'], null, null, null, false, false, null]],
        '/reactivate-user' => [[['_route' => 'reactivate-user', '_controller' => 'App\\Controller\\UserController::reactivateUser'], null, null, null, false, false, null]],
        '/delete-user' => [[['_route' => 'delete-user', '_controller' => 'App\\Controller\\UserController::deleteUser'], null, ['GET' => 0], null, false, false, null]],
        '/upload-terms-of-use' => [[['_route' => 'upload-terms-of-use ', '_controller' => 'App\\Controller\\UserController::uploadTermsOfUse'], null, ['POST' => 0], null, false, false, null]],
        '/upload-privacy-policy' => [[['_route' => '/upload-privacy-policy ', '_controller' => 'App\\Controller\\UserController::uploadPrivacyPolicy'], null, ['POST' => 0], null, false, false, null]],
        '/get-privacy-policy' => [[['_route' => '/get-privacy-policy ', '_controller' => 'App\\Controller\\UserController::getPrivacyPolicy'], null, ['POST' => 0], null, false, false, null]],
        '/get-terms-of-use' => [[['_route' => 'get-terms-of-use ', '_controller' => 'App\\Controller\\UserController::getTermsOfUse'], null, ['POST' => 0], null, false, false, null]],
        '/get-instructions' => [[['_route' => 'get-instructions', '_controller' => 'App\\Controller\\UserController::getInstructions'], null, ['POST' => 0], null, false, false, null]],
        '/upload-instructions' => [[['_route' => 'upload-instructions', '_controller' => 'App\\Controller\\UserController::uploadInstructions'], null, ['POST' => 0], null, false, false, null]],
        '/logout' => [[['_route' => 'api_logout'], null, null, null, false, false, null]],
        '/PdfFile' => [[['_route' => 'png_list'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        35 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
