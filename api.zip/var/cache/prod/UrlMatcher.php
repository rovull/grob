<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/announcement' => [[['_route' => 'announcement', '_controller' => 'App\\Controller\\AnnouncementController::index'], null, null, null, false, false, null]],
        '/add_announcement' => [[['_route' => 'add_announcement', '_controller' => 'App\\Controller\\AnnouncementController::addAnnouncement'], null, ['POST' => 0], null, false, false, null]],
        '/user' => [[['_route' => 'user', '_controller' => 'App\\Controller\\UserController::index'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'api_login', '_controller' => 'App\\Controller\\UserController::login'], null, ['POST' => 0], null, false, false, null]],
        '/register' => [[['_route' => 'api_register', '_controller' => 'App\\Controller\\UserController::register'], null, ['POST' => 0], null, false, false, null]],
        '/profile' => [[['_route' => 'api_profile', '_controller' => 'App\\Controller\\UserController::profile'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'api_logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
    ],
    [ // $dynamicRoutes
    ],
    null, // $checkCondition
];
