<?php


namespace App\Controller;
use App\Entity\Invoices;
use App\Repository\InvoicesRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;


class InvoicesController extends AbstractController
{
    /**
     * @Route("/get-all-bills", name="get-all-bills", methods={"GET"})
     * @param InvoicesRepository $repo
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @throws \Spatie\PdfToImage\Exceptions\PdfDoesNotExist
     * @throws \Spatie\PdfToImage\Exceptions\InvalidFormat
     */
    public function allInvoices(InvoicesRepository $repo,Request $request)
    {

        $appeal = $request->query->get("filter");
        if ($appeal){
            if($appeal=='paid'){
                $appeal= 1;
            }else{
                $appeal=0;
            }
            $invoices = $repo->findAllFilter($appeal);
        }elseif (!$appeal) {
            $invoices = $repo->findAll();
        }

            $result = array();
            foreach ($invoices as $object) $result[] = (array)$object;
            return $this->json(
                $result
            );



    }

    /**
     * @Route("/get-all-invoices", name="get-all-invoices", methods={"GET"})
     * @param InvoicesRepository $repo
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @throws \Spatie\PdfToImage\Exceptions\PdfDoesNotExist
     * @throws \Spatie\PdfToImage\Exceptions\InvalidFormat
     */
    public function allInvoicesByUser(InvoicesRepository $repo,Request $request)
    {
        $appeal = $request->query->get("user_id");
        $invoices = $repo->findByUser($appeal);
        $result = array();
        foreach ($invoices as $object) $result[] = (array)$object;
        return $this->json(
            $result
        );

    }

    /**
     * @Route("/edit-bill-payment", name="edit-bill-paymen", methods={"GET"})
     * @param InvoicesRepository $repo
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @throws \Spatie\PdfToImage\Exceptions\PdfDoesNotExist
     * @throws \Spatie\PdfToImage\Exceptions\InvalidFormat
     */
    public function updateBill(InvoicesRepository $repo,Request $request)
    {
        $appeal = $request->query->get("bill_id");
        $appeal2 = $request->query->get("paid");

        if($appeal2=='true'){
            $appeal2= 1;
        }else{
            $appeal2=0;
        }

        if($appeal){
            $repo->updateBill($appeal,$appeal2);
            return $this->json(
                'success'
                ,200);
        }
        return $this->json(''
            ,400);

    }
    /**
     * @Route("/edit-bill-sum", name="edit-bill-sum", methods={"GET"})
     * @param InvoicesRepository $repo
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\JsonResponse
     * @throws \Spatie\PdfToImage\Exceptions\PdfDoesNotExist
     * @throws \Spatie\PdfToImage\Exceptions\InvalidFormat
     */
    public function updatePrice(InvoicesRepository $repo,Request $request)
    {
        $appeal = $request->query->get("bill_id");
        $appeal2 = $request->query->get("sum");
        if($appeal and $appeal2 ){
            $repo->updatePrice($appeal,$appeal2);
            return $this->json(
                'success'
                ,200);
        }
        return $this->json(''
            ,400);

    }

}