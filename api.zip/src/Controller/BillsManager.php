<?php
declare(strict_types=1);

namespace App\Controller;
use Swift_Mailer;
use MyBuilder\Bundle\CronosBundle\Annotation\Cron;
use Swift_SmtpTransport;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
/**
 * @Cron(minute="/2", noLogs=true)
 */
class BillsManager extends Command
{
    protected function configure()
    {
        $this
            ->setName('bills:create')
            ->setDescription('Create a bills.');
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int|void
     */
    public function execute(InputInterface $input, OutputInterface $output){
        $transport = (new Swift_SmtpTransport('smtp.gmail.com', 465,'ssl'))
            ->setUsername('gbcoding999@gmail.com')
            ->setPassword('Luctio123')
        ;
        $mailer = new \Swift_Mailer($transport);
            $message = (new \Swift_Message('Luct.io'))
                ->setFrom('gbcoding999@gmail.com')
                ->setTo('yaskovetc@gmail.com')
                ->setBody('lox'
                );
            $mailer->send($message);


}}